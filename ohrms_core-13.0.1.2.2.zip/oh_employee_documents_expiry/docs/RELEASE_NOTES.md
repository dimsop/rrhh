## Module 'hr_employee_documents_expiry'

#### 22.05.2019
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Open HRMS Project


#### 25.02.2020
#### Version 13.0.2.0.0
##### UPDT
- Expiry notification configuration
- Document types
- Document Templates for managers
