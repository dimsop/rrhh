## Module <ohrms_core>

#### 22.10.2018
#### Version 13.0.1.0.0
##### ADD
- Initial commit for Open HRMS Core Module

#### 30.10.2018
#### Version 13.0.1.1.0
##### FIX
- Bug Fixed.

#### 27.02.2020
#### Version 13.0.1.2.1
##### FIX
- Bug Fixed.
